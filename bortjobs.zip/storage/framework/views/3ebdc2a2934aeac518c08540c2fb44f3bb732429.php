<div>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('filtrar-vacantes', [])->html();
} elseif ($_instance->childHasBeenRendered('l2617646936-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l2617646936-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l2617646936-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l2617646936-0');
} else {
    $response = \Livewire\Livewire::mount('filtrar-vacantes', []);
    $html = $response->html();
    $_instance->logRenderedChild('l2617646936-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto">
            <h3 class="font-extrabold text-4xl text-gray-700 mb-12">
                Nuestras ofertas disponibles
            </h3>
            <div class="bg-white shadow-sm rounded-lg p-6 divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $vacantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vacante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="md:flex md:justify-between md:items-center py-5">
                        <div class="md:flex-1">
                        <a class="text-3xl font-extrabold text-gray-600" href="<?php echo e(route('vacantes.show', $vacante->id)); ?>">
                                <?php echo e($vacante->titulo); ?>

                        </a>
                        <p class="text-base text-gray-600 mb-1">
                            <?php echo e($vacante->empresa); ?>

                        </p>
                        <p class="text-xs font-bold text-gray-600 mb-1">
                            <?php echo e($vacante->categoria->categoria); ?>

                        </p>
                        <p class="text-base text-gray-600 mb-1">
                            <?php echo e($vacante->salario->salario); ?>

                        </p>
                        <p class="font-bold text-xs text-gray-600"> Último día para inscribirse
                            <span class="font-normal">
                                <?php echo e($vacante->ultimo_dia->format('d/m/Y')); ?>

                            </span>
                        </p>
                        </div>
                        <div class="mt-5 md:mt-0">
                            <a class="bg-indigo-500 p-3 text-sm uppercase font-bold text-white rounded-lg block text-center" href="<?php echo e(route('vacantes.show', $vacante->id)); ?>">
                                Ver oferta
                            </a>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="p-3 text-center text-sm text-gray-600">
                        Todavía no hay ninguna oferta
                    </p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /opt/lampp/htdocs/tutorial laravel/devjobsbort/resources/views/livewire/home-vacantes.blade.php ENDPATH**/ ?>