<?php echo e($slot); ?>

<?php /**PATH /opt/lampp/htdocs/tutorial laravel/devjobsbort/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>