<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Candidatos oferta')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">
                  <h1 class="text-2xl font-bold text-center my-10">Candidatos oferta: <?php echo e($vacante->titulo); ?></h1>

                  <div class="md:flex md:justify-center p-5">
                    <ul class="divide-y divide-gray-200 w-full">
                      <?php $__empty_1 = true; $__currentLoopData = $vacante->candidatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <li class="p-3 flex items-center">
                        <div class="flex-1">
                          <p class="text-xl font-medium text-gray-800"><?php echo e($candidato->user->name); ?></p>
                          <p class="text-sm text-gray-600"><?php echo e($candidato->user->email); ?></p>
                          <p class="text-sm font-medium text-gray-600">Día de inscripción: <span class="font-normal"><?php echo e($candidato->created_at->diffForHumans()); ?></span></p>
                        </div>
                        <div>
                          <a 
                          href="<?php echo e(asset('storage/cv/'.$candidato->cv)); ?>"
                          class="inline-flex items-center shadow-sm px-3 py-2 border border-gray-300 text-sm leading-5 font-medium rounded-full text-gray-700 bg-white hover:bg-gray-50"
                          target='_blank'
                          rel="noreferrer noopener"
                          >
                            Ver Cv
                          </a>
                        </div>
                      </li>
                        
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="p-3 text-center text-sm text-gray-600">No hay candidatos</p>
                      <?php endif; ?>
                    </ul>
                  </div>  
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/tutorial laravel/devjobsbort/resources/views/candidatos/index.blade.php ENDPATH**/ ?>