<?php
    $classes = "text-sm text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md
    focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
?>

<div>
    <a <?php echo e($attributes->merge(['class'=>$classes])); ?>>
    <?php echo e($slot); ?>

    </a>
</div><?php /**PATH /opt/lampp/htdocs/tutorial laravel/devjobsbort/resources/views/components/link.blade.php ENDPATH**/ ?>